const data = {
    email: "standard_user",
    password: "secret_sauce",
    sortValues: {
        nameAtoZ: "az",
        nameZtoA: "za",
        priceLtoH: "lohi",
        priceHtoL: "hilo"
    }
}
export default data;
